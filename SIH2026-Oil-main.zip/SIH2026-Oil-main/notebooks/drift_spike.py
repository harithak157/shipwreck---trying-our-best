from datetime import timedelta, datetime
from opendrift.models.oceandrift import OceanDrift
from opendrift.readers import reader_constant, reader_global_landmask
import os

def run_drift_spike():
    print("Initializing OceanDrift for backward simulation...")
    o = OceanDrift(loglevel=50)
    
    print("Adding landmask reader...")
    reader_landmask = reader_global_landmask.Reader()
    o.add_reader(reader_landmask)
    
    print("Adding a constant mock current (0.5 m/s East, 0.2 m/s North)...")
    r = reader_constant.Reader({'x_sea_water_velocity': 0.5, 'y_sea_water_velocity': 0.2})
    o.add_reader(r)
    
    print("Seeding 100 particles at estimated spill location (Offshore Ennore)...")
    start_time = datetime(2017, 1, 28, 4, 0, 0)
    o.seed_elements(lon=80.5, lat=13.2, time=start_time, number=100)
    
    print("Running backward drift simulation for 12 hours...")
    os.makedirs('docs/ppt_assets', exist_ok=True)
    o.run(duration=timedelta(hours=12), time_step=-3600, outfile='docs/ppt_assets/backward_run.nc')
    
    print("Attempting to plot...")
    try:
        o.plot(filename='docs/ppt_assets/backward_drift_plot.png', fast=True)
        print("Plot saved to docs/ppt_assets/backward_drift_plot.png")
    except Exception as e:
        print(f"Plotting failed: {e}")
        
    print("Spike simulation completed successfully.")
    
if __name__ == "__main__":
    run_drift_spike()
