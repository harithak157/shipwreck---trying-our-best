import sys
import os
sys.path.insert(0, os.path.abspath('.'))
from fastapi.testclient import TestClient
from backend.api.main import app
import json

client = TestClient(app)

def run_tests():
    print("--- Testing /api/detection/properties ---")
    r1 = client.get("/api/detection/properties")
    print("Status:", r1.status_code)
    print("JSON Response:")
    print(json.dumps(r1.json(), indent=2))
    
    print("\n--- Testing /api/drift/origin ---")
    r2 = client.get("/api/drift/origin")
    print("Status:", r2.status_code)
    print("JSON Response:")
    print(json.dumps(r2.json(), indent=2))
    
    print("\n--- Testing /api/attribution/suspects ---")
    r3 = client.get("/api/attribution/suspects")
    print("Status:", r3.status_code)
    print("JSON Response:")
    print(json.dumps(r3.json(), indent=2))

if __name__ == "__main__":
    run_tests()
