import sys
import subprocess

def run_script(name, path):
    print(f"\n==================================================")
    print(f"RUNNING {name}")
    print(f"==================================================")
    try:
        result = subprocess.run([sys.executable, path], capture_output=True, text=True, check=True)
        print("STDOUT:")
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print("FAILED!")
        print("STDOUT:")
        print(e.stdout)
        print("STDERR:")
        print(e.stderr)

if __name__ == "__main__":
    run_script("Detection Spike", "notebooks/detection_spike.py")
    run_script("Attribution Spike", "notebooks/attribution_spike.py")
    run_script("Drift Spike", "notebooks/drift_spike.py")
    run_script("Backend/API Spike", "notebooks/test_api_spike.py")
