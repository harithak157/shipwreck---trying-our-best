import torch
import torchvision.models.segmentation as segmentation

def run_detection_spike():
    print("Loading pre-trained FCN (as a stand-in for U-Net)...")
    model = segmentation.fcn_resnet50(pretrained=False, num_classes=3) # oil, water, look-alike
    model.eval()
    
    # Dummy SAR image (1 batch, 3 channels, 256x256)
    print("Generating dummy SAR image tensor (1, 3, 256, 256)...")
    dummy_input = torch.randn(1, 3, 256, 256)
    
    with torch.no_grad():
        output = model(dummy_input)['out']
    
    print(f"Inference complete. Output shape: {output.shape}")
    print("Spike successful: Dummy segmentation mask generated.")

if __name__ == "__main__":
    run_detection_spike()
