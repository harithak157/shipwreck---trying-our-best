import pandas as pd
from datetime import datetime

def run_attribution_spike():
    print("Generating synthetic AIS data for demo region...")
    data = {
        'mmsi': ['419000000', '419000001', '419000002'],
        'lat': [13.21, 13.50, 12.90],
        'lon': [80.32, 80.40, 80.10],
        'timestamp': ['2017-01-28 10:00:00', '2017-01-28 12:00:00', '2017-01-28 09:00:00'],
        'vessel_type': ['Tanker', 'Tanker', 'Cargo']
    }
    df = pd.DataFrame(data)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    print("Filtering AIS data by space-time window...")
    # Origin estimate center: 13.2 lat, 80.3 lon
    filtered_df = df[
        (df['lat'] > 13.0) & (df['lat'] < 13.4) &
        (df['lon'] > 80.2) & (df['lon'] < 80.4)
    ]
    print(f"Filtered to {len(filtered_df)} suspects.")
    print("Spike successful: AIS filter logic running.")

if __name__ == "__main__":
    run_attribution_spike()
