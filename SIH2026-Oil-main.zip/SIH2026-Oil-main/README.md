#  SIH26143: Marine Oil Spill Detection & Vessel Attribution

**Smart India Hackathon (SIH) 2026**

**Organization:** National Technical Research Organisation (NTRO)

**Category:** Software | **Theme:** Disaster Management

**Key Deadlines:**

* **PPT / Idea Submission:** 31 August 2026
* **Internal Hackathon (Build + Present):** 2-3 September 2026

---

## Problem Statement (SIH26143)

**Background:** Marine oil spills inflict great damage on marine ecosystems and several times remain un-attributable to the vessel causing such spills. Leveraging satellite imagery along with AIS data will enable detection of oil spills and vessel responsible for the same.

**Objective:** Design an intelligent automated pipeline to:

1. Detect and characterise the oil spill (calculating geometric properties and age if feasible).
2. Use oceanographic and meteorological data to trace the slick towards the origin point and time, and predict the future flow of the slick.
3. Analyse and attribute the spill to a vessel using historic AIS data to reconstruct vessel traffic around the origin window in space and time. Filter irrelevant traffic and score potential suspects based on proximity, trajectory, and behavioural anomalies.

**Approved Data Sources:** MarineCadastre AccessAIS (or synthetic for demo), Zenodo Sentinel-1 SAR Oil Spill Dataset, HYCOM (currents), and ECMWF ERA5 (wind).

**Validation Case:** 28 January 2017 Ennore/Chennai Oil Spill. (We will run our pipeline against this known case and compare our predicted drift to the published INCOIS/GNOME results to prove physical validity).

---

## Core Pipeline & Architecture

Our solution is a 4-stage chained pipeline. Each stage is owned by a dedicated team member and maps 1:1 to the `services/` folder structure.

| Stage | Owner | Description | Key Technologies |
| --- | --- | --- | --- |
| **1. Detection** | CV Lead | SAR image → oil slick segmentation mask → geometric properties. | `PyTorch`, `U-Net`, `rasterio`, `geopandas` |
| **2. Drift** | Reem | Physics-based hindcasting (backward) & forecasting (forward) to find the origin window. | `OpenDrift`, HYCOM (currents), ERA5 (wind) |
| **3. Attribution** | Data/ML Lead | Spatio-temporal filtering of AIS data + rule-based scoring & anomaly detection. | `pandas`, `movingpandas`, `scikit-learn` |
| **4. Visualization** | Frontend Lead | Dark-mode dashboard rendering the end-to-end pipeline. | `React`, `Leaflet`, `FastAPI` (Backend) |

> **Key Design Decisions:**
> * **Drift simulation is strictly physics-based (OpenDrift), not Deep Learning.** Oil drift is governed by known physics (advection, wind drag). A validated physical simulator is more credible and defensible than forcing a neural net onto it.
> * **Vessel attribution is a transparent, explainable rule-based scoring system, not a black-box model.** There is no labeled "guilty vessel" ground truth to supervise on, so evidence must be mathematically explainable.
> * **Simplified Backend:** FastAPI + SQLite instead of Express + PostGIS. PostGIS is deferred to post-hackathon to reduce immediate learning curves.
> 
> 

---

## Phase 0 Status & Known Issues

*(Updated: Pre-Hackathon Skeleton Build)*

The architecture skeleton is built, but **this is an MVP**. Do not treat Phase 0 as fully complete until verifying real outputs.

* **Detection:** Model loads (ResNet50 stand-in for U-Net) and runs successfully on a *dummy tensor*. No real SAR image used yet.
* **Drift (Reem's Stage):** OpenDrift backward run executes successfully. **Caveats:** Currently using a fabricated constant current (0.5 m/s E, 0.2 m/s N) and no wind forcing. The seed point is manually nudged offshore to `80.35°E` to dodge a landmask crash at the exact Ennore coordinate.
* **Attribution:** Synthetic AIS generation and spatio-temporal bounding box filters work. **Caveat:** The anomaly/scoring logic does not exist yet (proximity/trajectory scores are currently hardcoded).
* **Backend:** FastAPI boots, routing works, responses validate against Pydantic schemas. **Caveat:** Endpoints return static hardcoded JSON. Real ML/physics code is not yet invoked.
* **Frontend:** Raw React component code exists but is blocked. Node.js is not installed on the build machine, so it has never been executed or verified.

---

## Local Setup & Installation

### 1. Clone the Repository

```bash
git clone https://github.com/ReemHamraz/SIH2026-Oil.git
cd SIH2026-Oil

```

### 2. Backend / Python Environment

We use a single unified `requirements.txt` based on our strict approved library list.

```bash
# Create and activate virtual environment
python -m venv venv
# On Windows: venv\Scripts\activate
# On Mac/Linux: source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Start the FastAPI server
cd backend
uvicorn api.main:app --reload

```

*API Docs will be available at `http://localhost:8000/docs*`

### 3. Frontend / React Environment

*(Ensure Node.js is installed on your machine)*

```bash
cd frontend
npm install
npm run dev

```

---

## Team Workflow & Branching Rules (Strict)

To ensure our P0 MVP runs cleanly for the 31 August PPT deadline, follow these rules explicitly (defined in `docs/rules.md`):

1. **Branch per Stage:** You must work on your designated branch. DO NOT push directly to `main`.
```bash
git checkout -b detection   # For Stage 1
git checkout -b drift       # For Stage 2 
git checkout -b attribution # For Stage 3
git checkout -b frontend    # For Stage 4

```


2. **Folder Isolation:** Only edit files inside your designated `services/<stage>/` folder (or `backend/`, `frontend/`). No one edits another person's stage folder directly. If a cross-stage fix is needed, flag it to that stage's owner.
3. **Data Contracts:** All cross-stage data MUST pass through the Pydantic models defined in `services/common/schemas.py`. Never invent schema fields.
4. **Update `docs/memory.md`:** This is the single source of truth for the project. Update the snapshot table and add a session log entry **after every meaningful work session**, not just once a day.
5. **Merging:** Merges to `main` only happen when your stage's P0 scope runs without error on the fixed Ennore demo scenario.
6. **AI Assistant Rules:** Never let an AI assistant fabricate metrics, sample results, or fake outputs for the PPT. Every number and plot must come from an actual run of the code.
