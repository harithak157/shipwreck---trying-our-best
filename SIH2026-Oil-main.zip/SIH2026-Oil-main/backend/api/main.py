from fastapi import FastAPI
from services.common.schemas import SpillProperties, OriginEstimate, RankedSuspects, SuspectVessel

app = FastAPI(title="SIH26143 API", description="Oil Spill Detection & Vessel Attribution API")

@app.get("/api/detection/properties", response_model=SpillProperties)
def get_spill_properties():
    return SpillProperties(
        area_sq_km=15.2,
        perimeter_km=25.4,
        elongation_index=3.1,
        age_heuristic_label="several hours"
    )

@app.get("/api/drift/origin", response_model=OriginEstimate)
def get_origin_estimate():
    return OriginEstimate(
        lat_center=13.2,
        lon_center=80.3,
        radius_km=5.0,
        time_window_start_utc="2017-01-28T04:00:00Z",
        time_window_end_utc="2017-01-28T16:00:00Z"
    )

@app.get("/api/attribution/suspects", response_model=RankedSuspects)
def get_ranked_suspects():
    return RankedSuspects(
        suspects=[
            SuspectVessel(
                mmsi="419000000",
                name="BW MAPLE",
                vessel_type="Tanker",
                proximity_score=0.95,
                trajectory_score=0.90,
                anomaly_score=0.85,
                combined_score=0.92
            ),
            SuspectVessel(
                mmsi="419000001",
                name="DAWN KANCHIPURAM",
                vessel_type="Tanker",
                proximity_score=0.92,
                trajectory_score=0.85,
                anomaly_score=0.88,
                combined_score=0.89
            )
        ]
    )
