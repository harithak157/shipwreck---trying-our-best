# Ennore Port Oil Spill (2017) - Validation Details

- **Date:** 28 January 2017, ~04:00 IST
- **Location:** Off Kamarajar Port (Ennore), Chennai, India (Approx 13.2° N, 80.3° E)
- **Incident:** Collision between LPG tanker *BW Maple* and petroleum tanker *Dawn Kanchipuram*.
- **Spill Volume:** Initially estimated at 20-100 tonnes, later revised upward.
- **Reference Output:** INCOIS published GNOME trajectory simulations matching the observed spread along the Marina beach coastline.
- **Use Case:** We will use this event's date and coordinates to validate our backward-drift (attribution) and forward-drift (spread) simulations, comparing our ranked suspect list against the known culprit (*Dawn Kanchipuram*).
