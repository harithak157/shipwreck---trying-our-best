from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

# Stage 1: Detection Outputs
class SpillProperties(BaseModel):
    area_sq_km: float = Field(..., description="Area of the spill in square kilometers")
    perimeter_km: float = Field(..., description="Perimeter of the spill in kilometers")
    elongation_index: float = Field(..., description="Ratio of major to minor axis")
    age_heuristic_label: str = Field(..., description="Coarse age estimate, e.g., 'recent', 'several hours'")

class GeoJSONFeature(BaseModel):
    type: str = "Feature"
    geometry: Dict[str, Any]
    properties: Optional[Dict[str, Any]] = None

class SpillPolygonFeatureCollection(BaseModel):
    type: str = "FeatureCollection"
    features: List[GeoJSONFeature]

# Stage 2: Drift Simulation Outputs
class OriginEstimate(BaseModel):
    lat_center: float = Field(..., description="Estimated origin latitude")
    lon_center: float = Field(..., description="Estimated origin longitude")
    radius_km: float = Field(..., description="Uncertainty radius around origin")
    time_window_start_utc: str = Field(..., description="ISO8601 start time")
    time_window_end_utc: str = Field(..., description="ISO8601 end time")

# Stage 3: Attribution Outputs
class SuspectVessel(BaseModel):
    mmsi: str = Field(..., description="Maritime Mobile Service Identity")
    name: Optional[str] = Field(None, description="Vessel name if known")
    vessel_type: str = Field(..., description="Type of vessel (e.g., Tanker, Cargo)")
    proximity_score: float = Field(..., description="Score based on location match")
    trajectory_score: float = Field(..., description="Score based on path overlap")
    anomaly_score: float = Field(..., description="Score based on abnormal behavior (Isolation Forest)")
    combined_score: float = Field(..., description="Final combined ranking score")

class RankedSuspects(BaseModel):
    suspects: List[SuspectVessel]
