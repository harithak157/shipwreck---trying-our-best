import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

function App() {
  const ennoreCenter = [13.2, 80.3]; // Ennore Port

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#0B1D2A' }}>
      <header style={{ padding: '1rem', color: '#EAF2F4' }}>
        <h2>Marine Oil Spill Detection & Attribution</h2>
      </header>
      <main style={{ flex: 1, display: 'flex' }}>
        <div style={{ flex: 2, padding: '1rem' }}>
          <MapContainer center={ennoreCenter} zoom={10} style={{ height: '100%', width: '100%', borderRadius: '8px' }}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; OpenStreetMap contributors'
            />
            <Marker position={ennoreCenter}>
              <Popup>Estimated Spill Origin</Popup>
            </Marker>
          </MapContainer>
        </div>
        <aside style={{ flex: 1, padding: '1rem', backgroundColor: '#16293A', color: '#EAF2F4', marginLeft: '1rem', borderRadius: '8px' }}>
          <h3>Ranked Suspects</h3>
          <p>Awaiting pipeline output...</p>
        </aside>
      </main>
    </div>
  );
}

export default App;
