# rules.md — What to use, what to avoid, and error-handling boundaries

Last updated: [update this line every time the doc changes]

This file exists so all 6 of you (and any AI coding assistant helping any
of you) make consistent choices instead of six different ones. If you're
about to add a new library or change how a module handles failure, check
here first — and update this file if you make a real decision that isn't
covered yet.

---

## 1. Approved libraries by service (do not add outside this list without
a quick team check-in — new dependencies under time pressure are a common
way demos break the night before)

| Service | Approved | Do NOT introduce |
|---|---|---|
| `services/detection/` | torch, torchvision, rasterio, GDAL (via rasterio, not raw CLI calls in code), Shapely, numpy, opencv-python (for despeckling filters only) | tensorflow (we picked PyTorch — don't mix frameworks), any AutoML/no-code CV tool |
| `services/drift/` | opendrift, xarray, netCDF4, numpy | pygnome (documented as backup only — don't install both unless actually switching) |
| `services/attribution/` | pandas, geopandas, movingpandas, scikit-learn (IsolationForest only, P1) | any deep-learning framework — attribution stays explainable/rule-based per `architecture.md`; do not sneak in a black-box classifier here |
| `backend/` | fastapi, uvicorn, pydantic | Node.js/Express (see `architecture.md` §3 — one backend language) |
| `frontend/` | react, leaflet, react-leaflet | Mapbox GL JS / Deck.gl (deferred — see `architecture.md`), any new state-management library beyond React's built-ins (Redux etc.) — this app's state is simple enough not to need it |
| Database | sqlite3 (stdlib) for MVP | PostGIS/PostgreSQL before P0 is fully working end-to-end |

---

## 2. Data contract discipline

Every stage handoff (SAR→detection output, detection→drift input,
drift→attribution input) must go through `services/common/schemas.py`
(pydantic models). Rules:

- **Never** pass a raw dict between stages when a schema exists — always
  validate against the pydantic model, even in a quick script.
- If you need a new field on a handoff, add it to `schemas.py` first and
  message the owner of the adjacent stage — don't just add a key and hope
  the next stage's code tolerates it.
- Every schema field needs a type and, where relevant, a unit in the field
  name or docstring (`area_sq_km`, not `area`) — geospatial unit
  confusion is one of the easiest ways to silently produce a wrong demo
  result.

---

## 3. Error-handling boundaries (including for AI-assisted code)

The team is under a 2-day build window, which is exactly the condition
under which people (and AI coding assistants) are tempted to either skip
error handling entirely or over-engineer it. Follow this instead:

### 3.1 What every pipeline stage MUST do
- **Fail loud, fail fast, fail with a message that names the stage.**
  A stage should never silently return an empty/default result on
  failure — raise an explicit exception that says which stage and what
  input caused it (`DetectionError: segmentation failed on
  scene_2017_01_28.tif — no valid mask returned`). A demo that crashes
  with a clear message mid-rehearsal is fixable; a demo that silently
  shows a blank/wrong result is not.
- **Validate inputs at the boundary of each stage**, not deep inside the
  logic — check the file/schema is well-formed the moment a stage
  receives it, before doing any expensive computation.
- **No bare `except:` clauses anywhere.** Catch specific exceptions you
  expect (`FileNotFoundError`, `ValidationError`, etc.) and re-raise
  anything unexpected rather than swallowing it.

### 3.2 What NOT to build (given the timeline)
- No retry/backoff logic for external API calls unless a specific call is
  observed to be flaky during testing — build it only when needed, not
  preemptively.
- No comprehensive logging framework setup (structured logging,
  log aggregation, etc.) — `print()`/basic `logging` module calls are
  fine for a hackathon demo. Revisit in `phases.md`'s post-hackathon
  phase if the project continues.
- No generic "catch everything and show a friendly error page" layer on
  the frontend for the hackathon MVP — if something breaks during
  rehearsal, you want to see the real error, not a swallowed one.

### 3.3 Rules specifically for AI-assisted coding (Claude Code / Copilot /
etc., since multiple team members will likely use AI assistance under
this timeline)

- **Never let an AI assistant silently invent a data schema.** If it
  proposes fields not in `services/common/schemas.py`, stop and update
  the schema file first, deliberately, not as a side effect of
  autocomplete.
- **Never let an AI assistant fabricate "sample results" or metrics**
  (accuracy numbers, precision/recall, demo values) to fill in a
  slide or a placeholder — every number in the PPT and the app must
  come from an actual run of the code. This is a hard rule: an
  invented-looking metric is exactly what falls apart under
  cross-questioning.
- **Review every AI-suggested dependency against the approved list in
  §1** before installing — AI assistants will often suggest a library
  that solves the immediate problem but isn't the one the team agreed
  on (e.g., suggesting Mapbox when the team is on Leaflet).
- **Keep AI-generated code inside the folder that matches its
  stage/owner** — don't let an assistant "helpfully" reach across
  service boundaries and edit another person's module; if a
  cross-stage fix is genuinely needed, flag it to that stage's
  owner instead of letting the assistant make the edit unreviewed.
- **Any AI-written physics/geospatial calculation (drift math, scoring
  formulas) needs a human sanity check against a known value** before
  it's trusted in the demo — e.g., does the backward-drift origin
  estimate land somewhere physically plausible (in the ocean, in the
  right general region), not just "the code ran without error."

---

## 4. Git / collaboration rules

- Branch per stage/person (`detection`, `drift`, `attribution`,
  `backend`, `frontend`), merge to `main` only when that stage's P0
  scope from `PRD.md` runs without error on the fixed demo scenario.
- No direct commits to `main` from more than one person without a quick
  message in the team chat — with 6 people over 2 days, silent
  conflicting pushes are the most likely thing to eat your remaining
  time.
- `memory.md` gets updated at the end of every work session by whoever
  worked — not just at the end of the day. See `memory.md` itself for
  the format.
