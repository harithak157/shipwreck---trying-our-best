# design.md — Visual design system

Last updated: [update this line every time the doc changes]

Purpose: so the dashboard looks like one coherent product built by one
team, not five components each styled by whoever happened to build them.
Frontend lead owns enforcing this; everyone else should default to these
values rather than picking their own when they touch any UI.

---

## 1. Design intent

This is an **investigative/analytical tool**, not a consumer app. The
visual tone should read as: serious, precise, maritime/oceanic, high
information density done cleanly — think a control-room dashboard, not a
marketing landing page. Avoid anything playful, cartoonish, or "AI demo"
generic (no glowing brain icons, no purple-blue AI-startup gradients).

---

## 2. Color palette

| Role | Color | Hex | Use for |
|---|---|---|---|
| Base background | Deep navy | `#0B1D2A` | Map container background, app shell |
| Secondary surface | Slate | `#16293A` | Panels, cards, sidebar |
| Primary accent | Signal cyan | `#2FB6C2` | Interactive elements, active states, links |
| Alert/attribution accent | Amber | `#E8A93C` | Suspect vessel highlighting, warnings, "look-alike" flags |
| Danger/spill accent | Coral red | `#E24E43` | Detected oil spill polygon overlay |
| Success/confirmed | Sea green | `#3FA687` | Validated/matched results (e.g. Ennore comparison match) |
| Text primary | Off-white | `#EAF2F4` | Body text on dark surfaces |
| Text secondary | Muted blue-gray | `#8FA6B2` | Captions, metadata, timestamps |
| Neutral border/divider | `#25384A` | Panel borders, table dividers |

Do not introduce additional accent colors beyond these without updating
this table — a 6-color palette used consistently reads more professional
to judges than a wider, inconsistent one.

## 3. Typography

| Use | Font | Notes |
|---|---|---|
| Headings / UI labels | **Inter** (or system-ui fallback) | Clean, highly legible at small sizes — good for dense dashboards |
| Body text | **Inter** | Keep one typeface family for the whole app; don't mix in a second display font |
| Numeric/data values (coordinates, scores, timestamps) | **IBM Plex Mono** or **JetBrains Mono** | Monospacing numbers in a data-heavy dashboard makes tables/scores easier to scan and reads as "serious tool," not "marketing site" |

Scale (rem, assuming 16px base):
- Page title: 1.75rem, semi-bold
- Panel headers: 1.125rem, semi-bold
- Body/labels: 0.875rem, regular
- Captions/metadata: 0.75rem, regular, secondary text color

## 4. Map & data-viz conventions

- Spill polygon: coral red fill at ~40% opacity, solid coral red outline.
- Drift path (past/hindcast): cyan dashed line.
- Drift path (future/forecast): cyan dotted line, lower opacity, to
  visually distinguish "known" from "predicted."
- Suspect vessel markers: amber, sized/opacity-scaled by suspect score
  (highest-ranked suspect = largest/most opaque marker) — this alone
  communicates ranking without needing a judge to read the sidebar.
- Ennore validation view: show your model's output and the published
  INCOIS result as two clearly labeled overlapping layers (e.g. solid
  vs. hatched fill) rather than side-by-side screenshots, if time
  allows — a true overlay is more convincing than a side-by-side.

## 5. PPT deck styling (should visually match the app, not be a separate
design language)

- Use the same palette above for the deck background/accents so the
  live demo doesn't feel like a jarring visual switch from the slides.
- Dark deck background (base navy) with the same accent colors for
  highlights/call-outs.
- Screenshots of the actual dashboard should be dropped in at full
  fidelity, not cropped/recolored to fit a different deck theme.
- One data point per slide where possible — resist the urge to cram
  every stat onto one slide; this is a formatting rule, not just a
  content rule.
