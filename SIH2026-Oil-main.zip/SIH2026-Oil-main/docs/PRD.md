# PRD.md — Project Requirements Document
## Marine Oil Spill Detection & Vessel Attribution System (SIH26143)

Status: Draft for Internal Hackathon (31 Aug PPT / 2-3 Sept build)
Owner: [team lead / PPT-validation lead]
Last updated: [update this line every time the doc changes]

---

## 0. Problem statement anchor (do not drift from this)

> Leveraging satellite imagery to determine oil spills at sea along with AIS
> data correlations to identify the vessel responsible for the spill.

Three required outputs, taken directly from the PS's "Expected Solution":
1. **Detection** — identify oil slicks from satellite imagery, with geometric
   properties and (if feasible) age.
2. **Hindcast + forecast** — map the slick's drift path backward to origin
   point/time and forward to predict future spread, using oceanographic +
   meteorological data.
3. **Attribution** — rank potential culprit vessels via spatio-temporal
   correlation with AIS data, filtering irrelevant traffic and scoring
   suspects on proximity, trajectory, and behavioral anomalies.
4. Plus: **a visual interface**.

Anything we build that isn't in service of these four points is scope creep.
When in doubt, cut it.

---

## 1. What to build

### 1.1 One-sentence definition
A pipeline + dashboard that takes a satellite SAR image, finds an oil slick,
figures out where and when it started, and tells you which ship was most
likely responsible — with a transparent, explainable score for every
suspect, not a black-box number.

### 1.2 MVP scope for internal hackathon (2-3 Sept) — what "done" means
Given the ~2-day build window, the MVP is **one working end-to-end run**,
not a polished multi-scenario product:

- [ ] One pre-selected SAR image → segmentation mask (oil vs. sea vs.
      look-alike) rendered on screen.
- [ ] Geometric properties (area, perimeter, centroid) computed and
      displayed for the detected slick.
- [ ] One OpenDrift backward run producing an estimated origin
      point + time window, and one forward run producing a predicted
      spread polygon.
- [ ] Synthetic AIS dataset for the demo region, filtered to the
      origin space-time window, scored, and ranked.
- [ ] A single-page dashboard showing all of the above on a map, with
      the ranked suspect list alongside.
- [ ] The Ennore 2017 validation comparison, pre-computed and shown as
      a static side-by-side (does not need to run live).

Explicitly **out of scope for the hackathon MVP** (stretch/later):
- Multi-image batch processing.
- Real-time/live AIS or live satellite feeds.
- User accounts, auth, persistence beyond a local/demo database.
- Age-estimation precision beyond a coarse heuristic label.
- Mobile responsiveness beyond "doesn't visibly break."

### 1.3 Post-hackathon scope (if shortlisted to nationals)
- Batch processing of multiple SAR scenes.
- Configurable region/time window instead of one hardcoded demo scenario.
- Model retraining/fine-tuning pipeline with tracked experiments.
- Deployment-grade error handling and logging (see `rules.md`).
- Additional validation case studies beyond Ennore.

---

## 2. Target users

Design every screen and every explanation with these three in mind — if a
feature doesn't serve one of them, question why it's there.

| User | What they need from this system | What they do NOT need |
|---|---|---|
| **Coast Guard / maritime enforcement analyst** | A fast, defensible shortlist of suspect vessels with *why* each one ranked where it did — this is evidence-adjacent, so opacity is a liability. | A raw ML confidence score with no explanation. |
| **Pollution control board / environmental regulator** | Spill extent, spread prediction, and impact-relevant geometry (area, drift toward coastline) to prioritize response. | Vessel-attribution detail — this user cares more about the spill than the culprit. |
| **SIH judges (our immediate, real target user for this deadline)** | A live, working demo that proves the pipeline is real, not a mockup; clear plain-language explanations at every stage; honesty about what's synthetic vs. real vs. estimated. | AI jargon, unexplained black-box outputs, overclaimed accuracy. |

---

## 3. Features (prioritized)

### P0 — must work for the hackathon demo
1. SAR image ingestion (from the pre-downloaded Zenodo/Krestenitis dataset)
2. Oil slick segmentation (oil / look-alike / sea, minimum viable class set)
3. Geometric property computation (area, perimeter, elongation)
4. Backward drift simulation → origin point + time estimate
5. Forward drift simulation → predicted spread
6. Synthetic AIS dataset generation for the demo region
7. AIS spatio-temporal filtering
8. Vessel suspect scoring (proximity, trajectory consistency, behavioral
   anomaly, vessel-type prior) with a transparent breakdown per vessel
9. Map dashboard: SAR overlay + spill polygon + drift path + ranked
   suspect list
10. Ennore 2017 validation comparison view (can be static/pre-generated)

### P1 — do if time allows after P0 is solid
11. Timeline slider to scrub through spill evolution
12. Age-estimation heuristic label (coarse: "recent" / "several hours" /
    "1+ day")
13. Look-alike misclassification example callout (for the pitch's
    "hard part we solved" slide)
14. Confidence/uncertainty display alongside each suspect score

### P2 — explicitly deferred, do not start these before P0/P1 are done
15. Multi-scenario support
16. Any authentication/user-management
17. Any live external API polling
18. Mobile layout optimization

---

## 4. Success criteria for the 31 Aug / 2-3 Sept milestone

- The PPT submitted by 31 Aug contains real screenshots from a running
  (even if rough) pipeline — not mockups.
- By end of Day 1 of the hackathon (2 Sept), P0 items 1-5 run end-to-end
  on the local machine of at least one team member.
- By end of Day 2 (3 Sept), the full P0 list is integrated and demoable
  live, with a recorded fallback video as backup.
- `memory.md` reflects real, current status at every check-in — no stale
  "in progress" entries.
