# phases.md — Phased build plan

Last updated: [update this line every time the doc changes]

This supersedes the earlier multi-week phase plan from the original
roadmap — that plan assumed weeks of runway. Given the real deadlines
(PPT due **31 Aug**, internal hackathon **2-3 Sept**), phases are
compressed. Do not silently revert to the longer timeline; if the team
advances past the internal round, add a new "Phase 5+: Post-hackathon"
section here rather than resurrecting the old one wholesale.

---

## Phase 0 — Setup & spikes (today → 28 Aug)

Goal: everyone has their environment running and has produced *something
real* — not a full build, just proof the approach works — so the PPT can
use real screenshots.

| Owner | Task | Definition of done |
|---|---|---|
| Detection lead | Download Krestenitis dataset sample; run an off-the-shelf U-Net (even under-trained) on 1-2 images | A real segmentation mask image exists on disk |
| Drift lead | Install OpenDrift; run its documented example scenario; confirm backtracking mode works | A real drift-path plot exists on disk |
| Attribution lead | Load MarineCadastre sample AIS; write basic spatio-temporal filter | Filter runs on sample data without error |
| Backend lead | Scaffold FastAPI app with stub endpoints matching `architecture.md` §1 flow | `uvicorn` runs, stub endpoints return dummy JSON matching the schemas |
| Frontend lead | Scaffold React + Leaflet app, static map renders | A map loads in the browser with a placeholder marker |
| Validation/PPT lead | Pull exact Ennore 2017 spill details (date, location, INCOIS's published GNOME result) | Citation-ready facts + source, and PPT skeleton with placeholders for each screenshot |

---

## Phase 1 — PPT build (28 → 30 Aug)

Goal: full draft deck, built around **real** outputs from Phase 0, not
mockups.

- 28 Aug: PPT skeleton gets real screenshots dropped in as they arrive.
- 29 Aug: full first draft done; team run-through with cross-questioning
  (see original roadmap doc's §7 question list).
- 30 Aug: fix everything flagged in the review; rehearse presenter
  delivery at least twice, timed.

## Phase 2 — Submission (31 Aug)

- Final proofread. Submit early in the day, not at the deadline.

## Phase 3 — Pre-hackathon buffer (1 Sept)

Goal: get the **thin-slice end-to-end demo** (Detection → Drift →
Attribution → dashboard, on the one fixed demo scenario) working at least
once, so hackathon time goes to polish, not first-time integration.

- Morning: each stage owner finalizes their P0 scope from `PRD.md`
  against the schemas in `services/common/schemas.py`.
- Afternoon: integration pairing per `architecture.md`'s "overlap
  points" — Detection+Drift owners pair on the polygon→seed-points
  handoff; Drift+Attribution owners pair on the origin-estimate→AIS-query
  handoff.
- End of day: `scripts/run_demo_pipeline.py` runs start to finish at
  least once without manual intervention, even if slow/rough.

## Phase 4 — Internal hackathon (2-3 Sept)

| Day | Focus |
|---|---|
| 2 Sept (Day 1) | Harden the end-to-end run from Phase 3; fix integration bugs; get the dashboard showing real (not stub) data from every stage; start on P1 features (timeline slider, age heuristic label) only once P0 is solid |
| 3 Sept (Day 2, AM) | Finish P1 items if time allows; record a fallback demo video in case live demo has issues; final rehearsal of the live walkthrough |
| 3 Sept (Day 2, PM) | Present |

---

## Phase 5+ — Post-hackathon (only fill this in if you advance)

Do not plan this in detail yet — revisit once you know the actual next
round's format and timeline. When you do, this is where the original
longer-runway items belong: PostGIS upgrade, Mapbox/Deck.gl upgrade,
multi-scenario support, retry/logging hardening, additional validation
case studies.
