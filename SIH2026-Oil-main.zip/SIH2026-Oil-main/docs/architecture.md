# architecture.md — App Flow, Folder Structure, Tech Stack

Last updated: [update this line every time the doc changes]

---

## 1. App flow (end to end)

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. INGEST                                                        │
│    SAR image (.tif, from Zenodo/Krestenitis dataset) loaded      │
│    into the pipeline.                                            │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. PREPROCESS  (services/detection/)                             │
│    Despeckle (Lee filter) → incidence-angle normalize →          │
│    tile/resize for model input.                                  │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. SEGMENT  (services/detection/)                                │
│    U-Net / DeepLabv3+ → per-pixel class mask                     │
│    (oil spill / look-alike / land / ship / sea).                 │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. CHARACTERIZE  (services/detection/)                           │
│    Mask → polygon (Shapely) → area/perimeter/elongation →        │
│    coarse age heuristic.                                         │
│    OUTPUT: spill_polygon.geojson + properties.json                │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 5. DRIFT SIMULATE  (services/drift/)                              │
│    spill_polygon + HYCOM currents + ERA5 wind → OpenDrift          │
│    → backward run (origin point + time window)                    │
│    → forward run (predicted spread at +6h/+12h/+24h)               │
│    OUTPUT: origin_estimate.json + forecast_polygons.geojson        │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 6. AIS FILTER + SCORE  (services/attribution/)                    │
│    origin_estimate → query AIS store for vessels within            │
│    space-time window → compute per-vessel sub-scores               │
│    (proximity, trajectory, behavioral anomaly, vessel-type prior)  │
│    → combined suspect score → ranked list.                         │
│    OUTPUT: ranked_suspects.json                                    │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 7. SERVE  (backend/api/)                                          │
│    FastAPI exposes all of the above as endpoints the frontend      │
│    calls. Each stage's output is cached/stored so the frontend     │
│    doesn't have to re-run the whole pipeline per interaction.      │
└───────────────────────────┬────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│ 8. VISUALIZE  (frontend/)                                          │
│    React + Leaflet/Mapbox: SAR overlay, spill polygon, drift        │
│    path (past+future), ranked suspect panel, Ennore validation      │
│    comparison view.                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Contract rule**: every stage reads only the file/JSON contract from the
stage before it, never reaches into another stage's internals. This is what
lets 6 people build in parallel without blocking each other — see
`rules.md` §2 for the exact schema each handoff must respect.

---

## 2. Folder & file structure

```
oilspill-attribution/
├── docs/                          # planning docs (this doc set)
│   ├── PRD.md
│   ├── architecture.md
│   ├── rules.md
│   ├── phases.md
│   ├── design.md
│   └── memory.md
│
├── data/                          # gitignored except .gitkeep + small samples
│   ├── raw/
│   │   ├── sar/                   # downloaded SAR scenes
│   │   └── ais/                   # MarineCadastre sample / synthetic AIS
│   ├── external/
│   │   ├── hycom/                 # cached current data for demo scenario
│   │   └── era5/                  # cached wind data for demo scenario
│   ├── processed/                 # intermediate outputs (polygons, masks)
│   └── validation/
│       └── ennore_2017/           # reference data + INCOIS result for comparison
│
├── services/
│   ├── detection/                 # Stage 1 — CV/Segmentation lead's territory
│   │   ├── preprocess.py          # despeckle, normalize
│   │   ├── model.py               # U-Net/DeepLabv3+ definition
│   │   ├── train.py
│   │   ├── infer.py               # run inference on a new image
│   │   ├── characterize.py        # polygon + geometric properties + age heuristic
│   │   └── tests/
│   │
│   ├── drift/                     # Stage 2 — Oceanography/Simulation lead's territory
│   │   ├── forcing_data.py        # fetch/cache HYCOM + ERA5
│   │   ├── run_opendrift.py       # backward + forward runs
│   │   ├── validate_ennore.py     # the validation case study script
│   │   └── tests/
│   │
│   ├── attribution/                # Stage 3 — AIS/Attribution lead's territory
│   │   ├── ais_ingest.py           # load real/synthetic AIS into common schema
│   │   ├── synth_ais.py            # synthetic AIS generator for demo region
│   │   ├── filter.py               # spatio-temporal filtering
│   │   ├── scoring.py              # per-vessel sub-scores + combined score
│   │   ├── anomaly.py              # optional Isolation Forest layer
│   │   └── tests/
│   │
│   └── common/                     # shared schemas/utilities — CHANGES HERE NEED
│       ├── schemas.py              # pydantic models for every handoff contract
│       └── geo_utils.py
│
├── backend/                        # Stage 4a — Backend/Integration lead's territory
│   ├── api/
│   │   ├── main.py                 # FastAPI app
│   │   ├── routes_detection.py
│   │   ├── routes_drift.py
│   │   ├── routes_attribution.py
│   │   └── routes_validation.py
│   └── tests/
│
├── frontend/                       # Stage 4b — Frontend/Dashboard lead's territory
│   ├── src/
│   │   ├── components/
│   │   │   ├── MapView.jsx
│   │   │   ├── SuspectPanel.jsx
│   │   │   ├── TimelineSlider.jsx
│   │   │   └── ValidationView.jsx
│   │   ├── App.jsx
│   │   └── api/                    # thin client calling the FastAPI backend
│   └── public/
│
├── notebooks/                      # exploratory work, NOT production code
│   └── (one notebook per person is fine here — keep messy work out of services/)
│
├── scripts/
│   ├── setup_env.sh
│   └── run_demo_pipeline.py        # single command that runs the whole P0 flow
│                                    #   end-to-end on the fixed demo scenario
│
├── .env.example
├── docker-compose.yml
├── requirements.txt                 # or split: requirements-ml.txt / requirements-api.txt
└── README.md
```

**Why this layout**: each `services/<stage>/` folder maps 1:1 to a team
role from `PRD.md`, so ownership is unambiguous. `services/common/schemas.py`
is the one file everyone must agree on before writing code against it —
treat changes to it as requiring a quick sync message, not a silent edit.

---

## 3. Tech stack (final, matches roadmap decisions — do not substitute
without updating this file)

| Layer | Choice | Why (not the alternative) |
|---|---|---|
| Segmentation model | PyTorch, U-Net (ResNet backbone) | Best-documented for SAR oil-spill segmentation in published work; faster to get a baseline running than DeepLabv3+ |
| SAR/geo processing | rasterio, GDAL, Shapely, geopandas | Standard scientific-Python geospatial stack |
| Drift simulation | OpenDrift | Has a maintained oil-drift module + built-in backtracking; do not build a custom physics simulator from scratch under this timeline |
| Forcing data | HYCOM (currents), ERA5 via Copernicus CDS (wind) | Free, standard datasets used by real oil-spill-response agencies |
| AIS processing | pandas, geopandas, movingpandas | movingpandas specifically handles trajectory objects, which saves reinventing trajectory logic |
| Anomaly sub-score (optional/P1) | scikit-learn IsolationForest | Simple, explainable, no GPU needed |
| Backend API | FastAPI | Async-friendly, fast to stand up, plays well with the Python-heavy ML stack — **do not introduce Node.js/Express**; one backend language only, given the timeline |
| Database (if needed beyond flat files) | SQLite for the hackathon MVP; PostGIS only if there's spare time post-MVP | SQLite is zero-setup and enough for a fixed demo scenario; don't spend hackathon hours standing up PostgreSQL+PostGIS for a single-scenario demo — this is a stretch item, not P0 |
| Frontend framework | React | Team default; fastest to find help/docs for under time pressure |
| Map rendering | Leaflet | Simpler and faster to get working than Mapbox GL/Deck.gl for a single-scenario demo; revisit Mapbox only if Leaflet visibly can't handle the data volume |
| Deployment for demo | Run locally / docker-compose on the presenting laptop | Do not depend on live cloud hosting for the hackathon demo — a local run that always works beats a cloud deployment that might go down mid-pitch |

**Note on the two prior drafts of this stack**: an earlier version of this
plan suggested Node.js/Express as a backend option and PostGIS as
non-negotiable, and Mapbox GL/Deck.gl for the frontend. Given the 31
Aug/2-3 Sept timeline, this version deliberately simplifies those choices
to reduce the number of new tools six people have to learn under time
pressure. If the team advances to nationals and has more runway, PostGIS
and Mapbox/Deck.gl are reasonable upgrades — track that decision in
`phases.md`, not by silently changing this file mid-hackathon.
