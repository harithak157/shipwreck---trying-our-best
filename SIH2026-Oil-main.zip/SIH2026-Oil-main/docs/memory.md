# memory.md — Live progress tracker

**Update this file at the end of every work session — not just once a
day.** This is the single source of truth for "what's actually done"
versus "what's planned" (that's in `phases.md`). If it's not updated here,
assume the team doesn't actually know it's done.

Format for each entry: `[date/time] [name] — [what changed]`

---

## Current status snapshot
*(rewrite this block each time you update — don't just append forever;
keep it a true current snapshot, and move detail history below it)*

| Stage | Status | Currently being worked on | Owner |
|---|---|---|---|
| Detection (Stage 1) | Phase 0 spike done (dummy tensor ONLY, no real SAR image) | — | [name] |
| Drift (Stage 2) | Phase 0 spike done (mock currents, offshore, no forward run) | — | [name] |
| Attribution (Stage 3) | Phase 0 spike done (filter ONLY, no scoring logic yet) | — | [name] |
| Backend (integration) | Phase 0 spike done (hardcoded JSON stubs, isolated) | — | [name] |
| Frontend (dashboard) | Blocked (No Node.js environment on host) | — | [name] |
| Validation / PPT | Phase 0 spike done | — | [name] |

**File currently being actively worked on (right now, this session):**
—

**Biggest current blocker (if any):** No Node.js environment on this machine; cannot bundle/run the React frontend.

---

## Session log

### [Aug 28, Session 2]
- **ACTUALLY EXECUTED ALL SPIKES** to verify Phase 0 completeness.
- **Detection**: Succesfully ran PyTorch dummy inference (resnet50 FCN). Mask shape confirmed.
- **Drift**: Installed `opendrift`. Discovered 13.2N 80.3E is classified as land by default landmasks, which instantly stranded backward-running particles. Moved seed slightly offshore (13.2N 80.5E) to prove backward advection logic works using a mock constant current (0.5m/s East, 0.2m/s North). Generated plot saved to `docs/ppt_assets/backward_drift_plot.png`.
- **Attribution**: Verified Pandas spatio-temporal filter on synthetic dataframe.
- **Backend**: Verified FastAPI stub endpoints output valid JSON matching Pydantic schemas.
- **Frontend**: Failed to run. `npm`/`npx` not installed on the host machine. React components are scaffolded in text but cannot be rendered locally yet.

### [Aug 28, Session 1]
- Reconciled folder structure and created all base directories/files as per `architecture.md`.
- Wrote `services/common/schemas.py` establishing Pydantic data contracts.
- Completed Phase 0 Spikes for all domains (Detection dummy inference, Drift OpenDrift skeleton, Attribution Pandas filtering, Backend FastAPI stubs, Frontend React+Leaflet skeleton, Validation Ennore summary).
- Ready to move to Phase 1 (PPT build) based on these real skeleton outputs.

### [Aug 27, kickoff]
- Repo skeleton + docs (`PRD.md`, `architecture.md`, `rules.md`,
  `phases.md`, `design.md`, `memory.md`) created.
- Roles assigned per `PRD.md`/`architecture.md`.
- No code written yet. Next: Phase 0 spikes (see `phases.md`).

---

## How to use this file (read once, then just follow the format)

1. Before you start working, glance at the snapshot table so you know
   what's already done and don't duplicate effort.
2. When you finish a session (even a short one), update:
   - The snapshot table row for your stage.
   - The "currently being worked on" line if you're stopping mid-file.
   - Add a session log entry with the date and what changed.
3. If you hit a blocker that affects another stage's owner, put it in
   the "biggest current blocker" line and message them directly — don't
   let it just sit in this file unnoticed.
4. Never mark a stage "Done" unless it actually runs without error on
   the fixed demo scenario — "done" here should mean the same thing it
   means in `PRD.md`'s Definition of Done, not "I wrote most of the
   code."
